#include <stdio.h>
#include <stdlib.h>
#include <string.h>

FILE *fili, *filo, *ftp, *f;

int main(int argv, char** argc)
{
	long a, b;
	if (argv == 2)
	{
		char fi[1000];				//input filename
		strcpy(fi, argc[argv-1]);
		strcat(fi, ".txt");
		char fo[1000];
		strcpy(fo, argc[argv-1]);
		strcat(fo, ".gml");			//both file names ready
		
		//printf("%s\n", fi);
		//printf("%s\n", fo);
		char c;
		ftp = fopen(fi, "r");
		f = fopen("temp.txt","w");
	
		while(~fscanf(ftp, "%c", &c))
			fprintf(f, "%c", c);		//data copied onto the temp.txt file
	
		fclose(ftp);
		fclose(f);
	
		ftp = fopen("temp.txt", "r+");
		long i, j;
		while(~fscanf(ftp, "%c", &c))
		{
			if(c=='#')
			{
				for(i=0 ; c!='\n' ; fscanf(ftp, "%c", &c), i++);
				fseek(ftp, -i-1, SEEK_CUR);
				for(j=0;j<i;j++)	fprintf(ftp, " ");	
			}				//every line starting with '#' is erased
		}
		fclose(ftp);
		long m,n;
		freopen("temp.txt", "r", stdin);
		freopen("tempp.txt", "w", stdout);
							//open both files as stdin and stdout
		while(~scanf("%ld %ld", &m, &n))
			printf("%ld %ld\n", m+1, n+1);

		fili = fopen("temp.txt", "r");
		long largest = 0;
		
		while(~fscanf(fili, "%ld", &a))
		{
			if(largest < a)
				largest = a;
		}					//largest - total number of nodes
		//printf("%ld",largest);
		fclose(fili);
		
		filo = fopen(fo, "w");
		fprintf(filo, "Creator \"Karan Bajaj - Source file: %s\"\n", fi);
		fprintf(filo, "graph\n[\n");
		
		for(i=0;i<=largest;i++)
		{
			fprintf(filo, "  node\n  [\n    id %ld\n  ]\n", (i+1));
		}
		
		fili = fopen("tempp.txt", "r");
		while(~fscanf(fili, "%ld %ld", &a, &b))
		{
			fprintf(filo, "  edge\n  [\n    source %ld\n    target %ld\n  ]\n", a, b);
		}
		fprintf(filo, "]");
		fclose(fili);
		fclose(filo);
		fclose(stdin);
		fclose(stdout);
		freopen("/dev/tty", "w", stdout);			
		printf("\nConversion complete!!!\nCheck file - %s\n\n", fo);
		remove("temp.txt");
		remove("tempp.txt");
	}
	else
	{
		printf("\nTXT2GML Converter - Karan Bajaj\n\nWould convert the .txt data file to .gml data file.\nDo not give '.txt' extension while entering file name.\nMissing : <filename> as parameter\n\n");
		exit(0);
	}
	return 0;
}
